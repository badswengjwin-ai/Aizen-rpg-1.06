(function(){
const m=document.querySelector('main'),w=document.getElementById('wrap'),b=document.getElementById('bar');
let raf=0,tm=0;
function fit(){raf=0;const cs=getComputedStyle(m),pw=parseFloat(cs.paddingLeft)+parseFloat(cs.paddingRight),ph=parseFloat(cs.paddingTop)+parseFloat(cs.paddingBottom),gap=parseFloat(cs.rowGap)||10;
const aw=m.clientWidth-pw,ah=m.clientHeight-ph-b.offsetHeight-gap-6;
if(aw<=0||ah<=0)return;
w.style.width=Math.max(200,Math.min(aw,ah*360/520))+'px'}
const req=()=>{clearTimeout(tm);tm=setTimeout(()=>{if(!raf)raf=requestAnimationFrame(fit)},120)};
addEventListener('resize',req);addEventListener('orientationchange',req);
if(window.visualViewport)visualViewport.addEventListener('resize',req);
if(window.ResizeObserver)new ResizeObserver(req).observe(b);
fit();
document.addEventListener('touchmove',e=>{if(!e.target.closest||!e.target.closest('#ov'))e.preventDefault()},{passive:false});
document.addEventListener('gesturestart',e=>e.preventDefault());
})();
