// ===== 파티·거래 =====
let PTY={m:[],l:''},TRD=null;const WRAP=document.getElementById('wrap'),gm=o=>ROOM&&ROOM.g&&ROOM.g(o),cls=()=>{O.style.display='none';st='play'},wnm=k=>(WP[k]&&WP[k][0])||k;
const IB=document.createElement('div');IB.style.cssText='position:absolute;left:6px;right:6px;top:6px;z-index:5;display:none;background:rgba(10,12,30,.94);border:2px solid #ffd84a;border-radius:6px;padding:8px;font-size:14px;text-align:center';WRAP.appendChild(IB);
function ask(txt,yes){IB.innerHTML=txt+'<br>';IB.style.display='block';[['수락',yes],['거절',()=>{}]].forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.style.cssText='width:45%;margin:6px 2% 0;padding:7px';b.onclick=()=>{IB.style.display='none';f()};IB.appendChild(b)});clearTimeout(ask.t);ask.t=setTimeout(()=>IB.style.display='none',15000)}
const PH=document.createElement('div');PH.style.cssText='position:absolute;left:6px;top:40px;font-size:11px;pointer-events:none;text-shadow:0 0 3px #000';WRAP.appendChild(PH);
setInterval(()=>{const b=document.getElementById('pt');if(b)b.hidden=!(ROOM&&ROOM.g)||st!=='play';if(!P){PH.innerHTML='';return}
PH.innerHTML=PTY.m.length>1?PTY.m.map(n=>{const q=n==ME?{hp:P.hp/P.max*100|0,lv:P.lv}:(PEERS.find(p=>p.presence.n==n)||{}).presence;return`<div>${n==PTY.l?'👑':''}${n} ${q?`Lv${q.lv} <span style="display:inline-block;width:40px;height:5px;background:#400"><i style="display:block;height:5px;width:${q.hp||0}%;background:#5ccf6b"></i></span>`:'(멀리)'}</div>`}).join(''):''},400);
function ptMenu(){st='ui';const b=[],lead=PTY.l==ME;
if(PTY.m.length>1)b.push(['🚪 파티 탈퇴',()=>{gm({a:'lv'});cls()}]);
if(lead)PTY.m.filter(n=>n!=ME).forEach(n=>b.push(['❌ '+n+' 추방',()=>{gm({a:'kick',n});cls()}]));
PEERS.forEach(p=>{const n=p.presence.n;if(PTY.m.includes(n))return;
b.push([`📨 ${n} Lv${p.presence.lv} 파티 초대`,()=>{gm({a:'inv',to:n});toast('초대를 보냈어요');cls()}]);
b.push([`🤝 ${n} 거래 신청`,()=>{gm({a:'tq',to:n});toast('거래를 신청했어요');cls()}])});
b.push(['닫기',cls]);
ov('👥 파티·거래',PTY.m.length>1?`파티: ${PTY.m.join(', ')}<br><small>파티원이 사냥하면 경험치·골드를 나눠 받아요 (가까이 있을 때)</small>`:'파티 없음<br><small>접속 중인 용사를 초대해 같이 사냥하세요</small>',b)}
const offr=o=>save(true).then(()=>gm({a:'to',...o}));
function trUI(){const t=TRD;if(!t)return;st='ui';const b=[],f=o=>`${o.g}G${o.w.length?' · '+o.w.map(wnm).join(', '):''}`;
if(!t.ml){[1000,10000,100000].forEach(x=>b.push([`💰 +${x}G`,()=>offr({g:Math.min(P.g,t.mine.g+x)})]));b.push(['💰 골드 초기화',()=>offr({g:0})]);
Object.keys(P.ow).filter(k=>P.ow[k]&&k!=P.w).forEach(k=>{const on=t.mine.w.includes(k);b.push([`${on?'✅':'⬜'} ${wnm(k)}`,()=>offr({w:on?t.mine.w.filter(x=>x!=k):[...t.mine.w,k]})])});
b.push(['🔒 제안 확정',()=>save(true).then(()=>gm({a:'tl'}))])}
else b.push([t.tl?(t.ok?'⏳ 상대 수락 대기 중':'✅ 최종 수락'):'⏳ 상대 확정 대기 중',()=>{if(t.tl&&!t.ok)gm({a:'tk'})}]);
b.push(['❌ 취소',()=>gm({a:'tc'})]);
ov(`🤝 ${t.p}님과 거래`,`내 제안: ${f(t.mine)}${t.ml?' 🔒':''}<br>상대 제안: ${f(t.theirs)}${t.tl?' 🔒':''}<br><small>장착 중인 무기는 거래할 수 없어요</small>`,b)}
const _kill=kill;kill=function(e){const v=e.gem;_kill(e);if(PTY.m.length>1&&v)gm({a:'sh',v})};
READY.then(()=>{if(!ROOM||!ROOM.g)return;document.getElementById('pt').onclick=()=>{if(st==='play')ptMenu()};ROOM.on('g',m=>{
if(m.a=='inv')ask(`📨 ${m.from}님이 파티에 초대했어요`,()=>gm({a:'acc',to:m.from}));
else if(m.a=='tq')ask(`🤝 ${m.from}님이 거래를 신청했어요`,()=>gm({a:'ta',to:m.from}));
else if(m.a=='pt'){PTY={m:m.m,l:m.l};toast(m.m.length>1?'👥 파티: '+m.m.join(', '):'👥 파티에서 나왔어요')}
else if(m.a=='sh'){const q=PEERS.find(p=>p.presence.n==m.from);if(!q||!P||Math.hypot(q.presence.x-P.x,q.presence.y-P.y)>600)return;const s=Math.ceil(m.v*.6);P.xp+=s;P.g+=s;toast(`👥 파티 +${s}`)}
else if(m.a=='tr'){TRD=m;if(P)trUI()}
else if(m.a=='td'){TRD=null;P.g+=m.get.g-m.give.g;m.give.w.forEach(k=>delete P.ow[k]);m.get.w.forEach(k=>P.ow[k]=1);cls();toast('🤝 거래 완료!');save(true)}
else if(m.a=='tx'){TRD=null;if(st=='ui')cls();toast(m.r||'거래 취소')}
else if(m.a=='er')toast(m.r)})});

const hx=a=>[...new Uint8Array(a)].map(b=>b.toString(16).padStart(2,'0')).join('');
const sha=async t=>hx(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(t)));
const pack=()=>{const o={};['lv','xp','nx','atk','g','pot','j','w','ow','os','ws','ows','hid','bk','sk','auto','ar','oar','dk','it','ks','eq','kc','uk','pk','bm','dc'].forEach(k=>o[k]=P[k]);o.pets=P.pets.map(p=>({s:p.s,d:p.d}));return o};
let LS='',LD=0;const lsk=k=>'yd:save:'+k;async function save(force){if(!ACC||!P||st!=='play')return;let s;try{s=JSON.stringify(pack())}catch(e){return}if(s===LS&&!force)return;LS=s;const t=Date.now();try{localStorage.setItem(lsk(ACC.k),JSON.stringify({h:ACC.h,p:s,t}))}catch(e){}if(!DB)return;if(!force&&t-LD<8000){LS='';return}LD=t;try{await DB.doc('accounts/'+ACC.k).set({h:ACC.h,p:s,t})}catch(e){LD=0;LS=''}}
setInterval(()=>save(),2000);addEventListener('pagehide',()=>save(true));addEventListener('beforeunload',()=>save(true));document.addEventListener('visibilitychange',()=>{if(document.hidden)save(true)});
function start(sv){reset();if(sv){const o=JSON.parse(sv);Object.assign(P,o,{pets:(o.pets||[]).map(p=>({...p,x:P.x,y:P.y,cd:0})),sc:[0,0,0,0],xc:[0,0,0],z:0,inv:0,dash:0,dd:0,cd:0});if(!P.ks.includes('rel'))P.ks.unshift('rel');if(P.j>=JB.length){P.j=0;P.dk=0}calc();P.hp=P.max}if(P.bk)E=E.filter(e=>!e.boss);st='play';toast(sv?'불러오기 완료!':'환영해요, '+ME+'!')}
function login(m){O.style.display='flex';O.innerHTML=`<h2>용사의 대륙</h2><p>${m||'아이디와 비밀번호를 입력하세요.<br>처음이면 새 계정이 만들어지고,<br>같은 정보로 다시 들어오면 이어서 해요.'}</p><input id="li" placeholder="아이디" maxlength="16" autocomplete="username"><input id="lp" type="password" placeholder="비밀번호 (4자 이상)" maxlength="32" autocomplete="current-password"><button id="lb">입장</button>`;document.getElementById('lb').onclick=enter}
async function enter(){startBGM();const id=document.getElementById('li').value.trim(),pw=document.getElementById('lp').value;if(id.length<2||pw.length<4)return login('아이디 2자 이상, 비밀번호 4자 이상이어야 해요.');
const k='u'+hx(new TextEncoder().encode(id.toLowerCase())),h=await sha('yd:'+k+':'+pw);CURH=h;await READY;ME=id;O.style.display='none';
let lc=null;try{lc=JSON.parse(localStorage.getItem(lsk(k))||'null')}catch(e){}if(!DB){if(lc){if(lc.h!==h)return login('비밀번호가 달라요.');ACC={k,h};start(lc.p);toast('⚠ 오프라인: 이 기기에서 이어서 해요')}else{ACC={k,h};start();save(true);toast('⚠ 오프라인: 이 기기에만 저장돼요')}return}
try{const sn=await DB.doc('accounts/'+k).get();if(sn.exists){const d=sn.data();if(d.h!==h){return login('비밀번호가 달라요.')}ACC={k,h};const useL=lc&&lc.h===h&&(lc.t||0)>(d.t||0);start(useL?lc.p:d.p);save(true)}else if(lc&&lc.h===h){ACC={k,h};start(lc.p);save(true)}else{ACC={k,h};start();save(true)}}catch(e){if(lc&&lc.h===h){ACC={k,h};start(lc.p);toast('⚠ 서버 연결 실패: 이 기기 저장분으로 이어서 해요')}else login('서버 연결 실패. 다시 시도해 주세요.')}}
