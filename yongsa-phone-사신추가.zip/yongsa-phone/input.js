// ---- input ----
const pt=e=>{const r=C.getBoundingClientRect();return{x:(e.clientX-r.left)*W/r.width,y:(e.clientY-r.top)*H/r.height}};
C.addEventListener('pointerdown',e=>{jo=pt(e);C.setPointerCapture(e.pointerId)});
C.addEventListener('pointermove',e=>{if(!jo)return;const p=pt(e);let dx=p.x-jo.x,dy=p.y-jo.y;const m=Math.hypot(dx,dy);if(m>40){dx=dx/m*40;dy=dy/m*40}jx=dx/40;jy=dy/40});
const up=()=>{jo=null;jx=jy=0};C.addEventListener('pointerup',up);C.addEventListener('pointercancel',up);
addEventListener('keydown',e=>{if(e.target.tagName==='INPUT')return;const k=e.key.toLowerCase();if(k===' '){dash();e.preventDefault()}if(k==='e')act();if(k==='q')usePot();if(k==='r')tame();if(k==='i'&&st==='play')invy();if(k.length==1&&'567'.includes(k))xskill(+k-5);if(k.length==1&&'1234'.includes(k))skill(+k-1);keys[k]=1});
addEventListener('keyup',e=>keys[e.key.toLowerCase()]=0);
document.getElementById('dash').onclick=dash;document.getElementById('pot').onclick=usePot;document.getElementById('tk').onclick=act;document.getElementById('tame').onclick=tame;
document.getElementById('ch').onclick=openChat;document.getElementById('jn').onclick=()=>{if(!PEERS.length||st!=='play')return;JI=(JI+1)%PEERS.length;const q=PEERS[JI].presence;P.x=q.x;P.y=q.y;E=E.filter(e=>e.boss);toast('👥 '+q.n+'님에게 합류!')};
