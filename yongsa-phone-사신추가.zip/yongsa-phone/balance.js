// ---- 레벨 밸런스 ----
// 기대 무기 공격력(레벨별 구매 가능 장비 기준) → 몬스터 HP는 '몇 방에 죽는가'로, 데미지는 '기대 체력의 몇 %'로 설계
const WXT=[[1,25],[5,90],[10,250],[20,800],[30,1300],[45,1700],[60,2000],[100,2300]];
const wx=L=>{for(let i=1;i<WXT.length;i++)if(L<=WXT[i][0]){const a=WXT[i-1],b=WXT[i];return a[1]+(b[1]-a[1])*(L-a[0])/(b[0]-a[0])}return 2300};
const expEA=L=>(10+3*(L-1)+wx(L))*(L<10?1:1.4);
const expHP=L=>100+20*(L-1);
const mHP=(L,k)=>Math.round(expEA(L)*(3.5+4*Math.min(1,L/80))*(k||1));
const mDM=(L,k)=>Math.max(3,Math.round(expHP(L)*.075*(k||1)));
const mGM=L=>Math.round(4+L**1.8*1.5);
const TY=[{t:0,s:'slime',hp:14,sp:.8,d:5,r:12,gem:2},{t:1,s:'bat',hp:10,sp:1.6,d:4,r:12,gem:3},{t:2,s:'skel',hp:36,sp:1,d:8,r:15,gem:5},{t:3,s:'boss',hp:900,sp:.9,d:18,r:30,gem:150},{t:4,s:'wolf',hp:30,sp:1.8,d:9,r:13,gem:6},{t:5,s:'crab',hp:24,sp:1,d:7,r:13,gem:5},{t:6,s:'golem',hp:90,sp:.7,d:16,r:16,gem:14},{t:7,s:'ghost',hp:55,sp:1.4,d:14,r:14,gem:12},{t:8,s:'dragon',hp:150,sp:1.1,d:22,r:22,gem:45}];
const TK={slime:[1,.8,.8],bat:[.8,.7,.9],skel:[1.2,1,1],boss:[1,1,1],wolf:[1.1,1.1,1],crab:[1,.9,1],golem:[2,1.4,1.5],ghost:[1.4,1.2,1.4],dragon:[3,1.8,3]};
TY.forEach(t=>{const k=TK[t.s];t.hk=k[0];t.dk=k[1];t.gk=k[2]});Object.assign(TY[3],{hp:200000,d:120,gem:40000});
const RG=[
{n:'슬라임의 숲',lv:[1,5],hp:220,m:[{s:'slime',h:1,dm:1,r:12,sp:.8},{s:'slimeB',h:1.6,dm:1.2,r:13,sp:.9}]},
{n:'고블린의 숲',lv:[5,10],hp:700,m:[{s:'goblin',h:1,dm:1,r:13,sp:1.3},{s:'goblinR',h:1.8,dm:1.3,r:14,sp:1.2}]},
{n:'늑대 무리',lv:[10,20],hp:1800,m:[{s:'wolf',h:1,dm:1,r:13,sp:1.9},{s:'wolfW',h:1.6,dm:1.25,r:14,sp:2}]},
{n:'오크들의 거처',lv:[20,30],hp:4000,m:[{s:'orc',h:1,dm:1,r:16,sp:1.1},{s:'orcO',h:1.7,dm:1.3,r:17,sp:1.2}]},
{n:'시 서펜트의 동굴',lv:[30,40],hp:7500,m:[{s:'serp',h:1,dm:1,r:16,sp:1.2},{s:'serpP',h:1.5,dm:1.2,r:16,sp:1.3}]},
{n:'지옥',lv:[40,50],hp:12000,m:[{s:'demon',h:1,dm:1,r:15,sp:1.4},{s:'imp',h:.8,dm:1.1,r:13,sp:1.9}]},
{n:'용의 동굴',lv:[50,70],hp:18000,m:[{s:'dragon',h:1,dm:1,r:20,sp:1},{s:'drakeB',h:1.5,dm:1.2,r:20,sp:1.1}]},
{n:'마왕성 내부',lv:[70,100],hp:30000,m:[{s:'knight',h:1,dm:1,r:16,sp:1.2},{s:'demonP',h:1.5,dm:1.3,r:16,sp:1.5}]}];


ZN.push(...RG.map(g=>`${g.n} Lv${g.lv[0]}~${g.lv[1]}`));
ZN[20]='🌌 보이드 차원 Lv80~300';
SP.vwraith=mk(["...kkkk...","..kMMMMk..",".kMUUUUMk.",".kMEUUEMk.",".kMUUUUMk.","kMMUUUUMMk","kMkMUUMkMk",".k.kMMk.k.","...k..k..."],3);
SP.veye=mk(["..kkkkkk..",".kMMMMMMk.","kMMwwwwMMk","kMwwEEwwMk","kMwwEEwwMk","kMMwwwwMMk",".kMMMMMMk.","..kkkkkk.."],3);
AUR.vwraith='#a54bff';AUR.veye='#d89cff';
SP.vskel=mk(["..kkkkkk..",".kppppppk.",".kwEppEwk.",".kwwwwwwk.","kkaapppakk","kaapaapaak","kwaaaaaawk",".kaa..aak.",".kaa..aak.",".kkk..kkk."],3);
SP.jorm=mk(["....kkkk....","...kggggk...","..kgEggEgk..","..kggRRggk..","...kkggkk...","....kggk....","...kggk.....","..kggkkkk...",".kgggggggk..","..kkkkkkk..."],3);
SP.vlich=mk([".Y.YYYY.Y.",".kYYYYYYk.",".kwwwwwwk.",".kwEwwEwk.",".kwwkkwwk.","kdppppppdk","kdppYYppdk","kdppppppdk",".kdpppppdk","..kkkkkkk."],3);
AUR.vskel='#9fb0d8';AUR.jorm='#4aa8ff';AUR.vlich='#5aa0ff';
{const LI=(k,u)=>{const im=new Image();im.onload=()=>{const c=SP[k];c.width=im.width;c.height=im.height;c.getContext('2d').drawImage(im,0,0)};im.src=u};LI('vlich',IM['images/c_001.png']);LI('vskel',IM['images/c_002.png']);LI('jorm',IM['images/c_003.png'])}
const DC=['#3d9a4a','#18381c','#8a9a70','#a07f4a','#2f6a80','#ff6a3a','#8a3a3a','#4a4a6a'];
const QS=[[0,5,'슬라임'],[1,6,'박쥐'],[2,6,'해골'],[0,15,'슬라임'],[2,15,'해골'],[1,25,'박쥐'],[2,30,'해골'],[3,1,'마왕']];
