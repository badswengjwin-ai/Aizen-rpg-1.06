function update(){
T++;
if(ROOM&&T%6==0)ROOM.presence({n:ME,x:P.x|0,y:P.y|0,sk:P.sk,f:P.f,lv:P.lv,hp:P.hp/P.max*100|0,j:P.j,mv:P.wt>0?1:0,at:(P.sw>0||P.sa>0)?1:0}).catch(()=>{});
const zt=M[(P.y/TS|0)*N+(P.x/TS|0)];if(zt!=P.z){P.z=zt;if(zt==11)toast('🐉 히든 맵 발견! 용의 굴');if(zt==10)toast('🕳️ 지하 던전');if(zt==20)toast('🌌 히든 맵 발견! 보이드 차원 (Lv80~300)');if(zt>=12&&zt<20){const g=RG[zt-12];toast(`📍 ${g.n} (Lv${g.lv[0]}~${g.lv[1]})`)}}
let vx=(keys.d||keys.arrowright?1:0)-(keys.a||keys.arrowleft?1:0)+jx,vy=(keys.s||keys.arrowdown?1:0)-(keys.w||keys.arrowup?1:0)+jy;
const m=Math.hypot(vx,vy);if(m>1){vx/=m;vy/=m}
if(vx)P.f=vx>0?1:-1;if(vx||vy)P.dr=Math.abs(vy)>Math.abs(vx)?(vy>0?0:3):(vx>0?2:1);if(P.dash>0&&!m)vx=P.f;
const sp=(P.dash>0?6:P.sp)*(zt==0?1.15:1);walkP(P,vx*sp,vy*sp,6);P.wt=(vx||vy)?(P.wt||0)+(P.dash>0?.3:.14):0;{const sl=zt==0;if(sl!=!!P.sl){toast(sl?'⛵ 출항! 배를 탔어요':'🏝️ 상륙!');P.sl=sl}}
P.dash--;P.dd--;P.inv--;P.cd--;P.bf--;for(let i=0;i<4;i++)P.sc[i]--;for(let i=0;i<3;i++)P.xc[i]--;FX=FX.filter(f=>--f.t>0);
const ar=AH||keys.z||keys.j||keys.k;
if(P.cd<=0&&(P.auto||ar)){const kd=WP[P.w][5];let hl=E.filter(e=>(!neu(e)||ar)&&Math.hypot(e.x-P.x,e.y-P.y)<P.rg+e.r+(ar?10:0));if(kd==3&&hl.length>1){hl.sort((a,b)=>Math.hypot(a.x-P.x,a.y-P.y)-Math.hypot(b.x-P.x,b.y-P.y));hl=[hl[0]]}if(hl.length||ar){hl.forEach(e=>{hurt(e,Math.round(P.ea*(P.bf>0?P.bm:1)));const a=Math.atan2(e.y-P.y,e.x-P.x),k=e.boss?1.5:kd==2?10:6;e.kx=Math.cos(a)*k;e.ky=Math.sin(a)*k});{const t0=hl[0];if(t0){const dx=t0.x-P.x,dy=t0.y-P.y;P.dr=Math.abs(dy)>Math.abs(dx)?(dy>0?0:3):(dx>0?2:1);if(dx)P.f=dx>0?1:-1}}P.cd=P.rate;P.sw=10}}
P.pets.forEach((p,i)=>{const tx=P.x-P.f*(22+i*16),ty=P.y+(i-1)*16,dx=tx-p.x,dy=ty-p.y;if(Math.hypot(dx,dy)>260){p.x=tx;p.y=ty}else walk(p,dx*.08,dy*.08,4);if(--p.cd<=0){const t=E.find(e=>!weak(e)&&!neu(e)&&Math.hypot(e.x-p.x,e.y-p.y)<44+e.r);if(t){hurt(t,p.d);p.cd=45}}});
E=E.filter((e,i,a)=>!e.boss||a.findIndex(q=>q.boss)==i);E=E.filter(e=>{const dx=P.x-e.x,dy=P.y-e.y,d=Math.hypot(dx,dy);if(d>650&&!e.boss&&!e.lg)return false;if(e.zk===undefined)e.zk=ZK(M[(e.y/TS|0)*N+(e.x/TS|0)]);const ox=e.x,oy=e.y;if(neu(e)){const a=T/90+e.x;(e.sea?walkS:walk)(e,Math.cos(a)*.3+e.kx,Math.sin(a)*.3+e.ky,4);e.kx*=.8;e.ky*=.8}else if(!e.boss||d<420){if(d<170&&d>1)(e.sea?walkS:walk)(e,dx/d*e.sp+e.kx,dy/d*e.sp+e.ky,4);else (e.sea?walkS:walk)(e,e.kx,e.ky,4);e.kx*=.8;e.ky*=.8;if(P.inv<=0&&d<e.r+10){P.hp-=Math.max(1,Math.round(e.d*gapDmg(e)*(1-AR[P.ar][1])));P.inv=40;e.am=18}}if(ZK(M[(e.y/TS|0)*N+(e.x/TS|0)])!==e.zk){e.x=ox;e.y=oy}return true});
E=E.filter(e=>e.hp>0||(kill(e),false));
CH.forEach(c=>{if(!c.o&&Math.hypot(P.x-c.x,P.y-c.y)<20){c.o=1;const g=(20+(Math.random()*40|0))*(c.b||1);P.g+=g;toast(`상자! +${g}G`);if(Math.random()<.05)learn('arc');if(Math.random()<.4){P.pot++;toast(`상자! +${g}G, 물약`)}}});
if(T%50==0&&E.filter(e=>!e.lg).length<16)spawn();if(T%60==0){const nw=Date.now();if(P.lk){const vg=LGS.find(q=>q.id=='void');if(vg&&!E.some(q=>q.lg=='void')){const d=mkLg(vg);d.x=P.lk.x;d.y=P.lk.y;E.push(d);toast('🌌 리치킹이 쓰러지자 보이드 드래곤이 나타났다!')}P.lk=0}LGS.forEach(g=>{if(g.id=='void')return;if(nw>=g.at&&!E.some(e=>e.lg==g.id))E.push(mkLg(g))})}
while(P.lv<100&&P.xp>=P.nx){P.xp-=P.nx;P.lv++;P.nx=Math.floor(20*P.lv**1.8);P.atk+=3;calc();P.hp=P.max;toast('레벨 업! Lv.'+P.lv+(P.lv==100?' MAX':''))}if(P.lv>=100)P.xp=0;
if(P.hp<=0){st='ui';P.dc=(P.dc||0)+1;const rv=()=>{P.hp=P.max;P.g>>=1;P.x=V[0].x;P.y=V[0].y+TS*2;E=E.filter(e=>e.boss);st='play'};if(P.dc>=20&&P.j!=13){ov('💀 죽음이 속삭인다...',`당신은 ${P.dc}번 쓰러졌다.<br>죽음에 익숙해진 자여,<br>사신이 되겠는가?`,[['💀 사신으로 전직',()=>{rv();chg(13)}],['아니요 (다시 일어나기)',rv]])}else ov('쓰러졌다...','마을에서 정신을 차렸어요. (골드 절반 잃음)',[['다시 일어나기',rv]])}
}
