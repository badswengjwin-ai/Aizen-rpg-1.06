// ===== 신규 직업: 사신 (직업 번호 13) =====
// 전직 조건: 20번 쓰러지면 사망 시 "사신으로 전직하시겠습니까?" 창이 뜸 (update.js)
// 거절해도 마을 '전직 안내소' NPC에게 말 걸면 다시 전직 가능
(function(){
const RID=13;
// 직업 [이름, 공격배율, 추가HP, 사거리+, 공속배율(작을수록 빠름), 이속+, 설명]
JB[RID]=['사신',2.5,250,25,.7,.5,'★히든: 죽음의 계약'];
// 스킬 [아이콘, 이름, 종류, 쿨타임, 범위/데미지범위, 데미지배율, 색, (추가값)]
SKJ[RID]=[
 ['💀','영혼 수확','arc',300,120,3.2,'#a54bff'],
 ['👻','망령 소환','multi',650,300,3.4,'#9ff0ff',5],
 ['🌑','죽음의 낫 폭풍','aoe',1100,200,7,'#6a3ac8'],
 ['☠️','사신의 심판','aoe',1800,260,11,'#ff2a4a']
];

// 사신 캐릭터 그림 (코드로 그림)
function art(){
 const c=document.createElement('canvas');c.width=144;c.height=136;
 const g=c.getContext('2d');
 // 낫 (오른쪽)
 g.save();g.shadowColor='#a54bff';g.shadowBlur=10;
 g.strokeStyle='#6b4423';g.lineWidth=5;g.lineCap='round';
 g.beginPath();g.moveTo(112,18);g.lineTo(100,128);g.stroke();
 g.fillStyle='#dfe8ff';g.beginPath();
 g.moveTo(112,16);g.quadraticCurveTo(138,6,142,40);g.quadraticCurveTo(128,22,110,26);g.closePath();g.fill();
 g.fillStyle='#a54bff';g.beginPath();
 g.moveTo(112,20);g.quadraticCurveTo(130,14,138,34);g.quadraticCurveTo(126,24,112,26);g.closePath();g.fill();
 g.restore();
 // 망토 (몸)
 g.fillStyle='#1a1030';g.beginPath();
 g.moveTo(40,58);g.quadraticCurveTo(66,48,92,58);g.lineTo(104,128);
 for(let x=104;x>28;x-=11.4){g.lineTo(x-5.7,118);g.lineTo(x-11.4,130)}
 g.lineTo(28,128);g.closePath();g.fill();
 g.strokeStyle='#6a3ac8';g.lineWidth=2;g.beginPath();g.moveTo(66,66);g.lineTo(66,124);g.stroke();
 // 후드
 g.fillStyle='#241545';g.beginPath();g.arc(66,46,31,0,Math.PI*2);g.fill();
 g.fillStyle='#0a0614';g.beginPath();g.ellipse(66,50,22,24,0,0,Math.PI*2);g.fill();
 // 해골 얼굴
 g.fillStyle='#efe8d8';g.beginPath();g.ellipse(66,50,15,17,0,0,Math.PI*2);g.fill();
 g.fillStyle='#0a0614';
 g.beginPath();g.ellipse(59,47,4.5,5.5,0,0,Math.PI*2);g.fill();
 g.beginPath();g.ellipse(73,47,4.5,5.5,0,0,Math.PI*2);g.fill();
 g.save();g.shadowColor='#ff2a4a';g.shadowBlur=8;g.fillStyle='#ff2a4a';
 g.beginPath();g.arc(59,48,2,0,7);g.fill();g.beginPath();g.arc(73,48,2,0,7);g.fill();g.restore();
 g.beginPath();g.moveTo(66,52);g.lineTo(63,58);g.lineTo(69,58);g.closePath();g.fill();
 g.strokeStyle='#0a0614';g.lineWidth=1.5;g.beginPath();g.moveTo(57,63);g.lineTo(75,63);g.stroke();
 for(let x=60;x<=72;x+=4){g.beginPath();g.moveTo(x,61);g.lineTo(x,65);g.stroke()}
 // 손 (낫 잡은 손)
 g.fillStyle='#efe8d8';g.beginPath();g.arc(102,84,6,0,7);g.fill();
 g.fillStyle='#241545';g.fillRect(92,80,10,10);
 return c.toDataURL('image/png');
}
const url=art();
JPD[RID]=url;
const im=new Image();im.src=url;JPI[RID]=im;

// 전직 안내소(마을 NPC)에 사신 전직 버튼 추가
const _guide=guide;
guide=function(){
 _guide();
 if(P.j===RID)return;
 const ok=(P.dc||0)>=20;
 const b=document.createElement('button');
 b.style.cssText='display:flex;align-items:center;justify-content:center;gap:8px;white-space:pre-line';
 if(ok){
  b.textContent='💀 히든 전직: 사신\n'+JB[RID][6];
  b.onclick=()=>{O.style.display='none';chg(RID)};
 }else{
  b.textContent='💀 ??? ('+(P.dc||0)+'/20번 쓰러짐)';
  b.disabled=true;
 }
 O.insertBefore(b,O.querySelector('button'));
};
})();
