// ---- world ----
const hs=(x,y,s)=>{const h=Math.sin(x*127.1+y*311.7+s*74.7)*43758.5453;return h-Math.floor(h)};
const vn=(x,y,s)=>{const xi=Math.floor(x),yi=Math.floor(y),xf=x-xi,yf=y-yi,u=xf*xf*(3-2*xf),v=yf*yf*(3-2*yf),a=hs(xi,yi,s),b=hs(xi+1,yi,s),c=hs(xi,yi+1,s),d=hs(xi+1,yi+1,s);return a+(b-a)*u+(c-a)*v+(a-b-c+d)*u*v};
const fb=(x,y,s)=>vn(x/12,y/12,s)*.6+vn(x/5,y/5,s+9)*.3+vn(x/2.3,y/2.3,s+3)*.1;
const M=new Uint8Array(N*N),V=[],CH=[];
for(let y=0;y<N;y++)for(let x=0;x<N;x++){const d=Math.hypot(x-N/2,y-N/2)/(N/2),e=fb(x,y,1)+.12-d*d*d*.55,m=fb(x,y,5);M[y*N+x]=e<.36?0:e<.41?1:e>.66?4:(m>.58&&hs(x,y,3)>.5)?3:2}
for(const sp of[40,32,24,18])for(let k=0;V.length<8&&k<2500;k++){const x=8+(hs(k,1,7)*(N-16)|0),y=8+(hs(k,2,7)*(N-16)|0);if(M[y*N+x]==2&&V.every(v=>Math.hypot(v.tx-x,v.ty-y)>sp)){V.push({tx:x,ty:y,x:(x+.5)*TS,y:(y+.5)*TS});for(let j=-4;j<=4;j++)for(let i=-4;i<=4;i++)M[(y+j)*N+x+i]=2;M[(y-2)*N+x-2]=M[(y-2)*N+x+2]=5}}
V.forEach((v,i)=>{const q=QS[i==V.length-1?QS.length-1:i];v.q={t:q[0],n:q[1],name:q[2],g:40+i*40,x:20+i*30,say:q[0]==3?'마왕이 마을을 위협해요! 처치해 주세요.':`${q[2]} ${q[1]}마리를 처치해 주세요!`}});
for(let y=0;y<N;y++)for(let x=0;x<N;x++){const t=M[y*N+x];if((t==1||t==2)&&V.every(v=>Math.hypot(v.tx-x,v.ty-y)>6)){if(y<N*.27)M[y*N+x]=6;else if(y>N*.74)M[y*N+x]=fb(x,y,11)>.6?8:7}}
{const v=V[0];for(let j=-5;j<=8;j++)for(let i=-9;i<=9;i++){const x=v.tx+i,y=v.ty+j;if(x>0&&y>0&&x<N-1&&y<N-1)M[y*N+x]=2}M[(v.ty-2)*N+v.tx-2]=M[(v.ty-2)*N+v.tx+2]=5}
let DG=null;for(let k=0;k<900&&!DG;k++){const x=20+(hs(k,8,5)*(N-40)|0),y=20+(hs(k,9,5)*(N-40)|0);if(M[y*N+x]==2&&Math.hypot(x-N/2,y-N/2)<N*.36&&y>N*.3&&y<N*.7&&V.every(v=>Math.hypot(v.tx-x,v.ty-y)>22))DG={tx:x,ty:y}}
if(DG)for(let j=-9;j<=9;j++)for(let i=-7;i<=7;i++){const d=Math.hypot(i,j),k=(DG.ty+j)*N+DG.tx+i;if(d<=6)M[k]=9;else if(d<=7.5)M[k]=Math.abs(i)<=1&&j>0?9:4;else if(j>7&&Math.abs(i)<=1)M[k]=2}
const carve=(D,t)=>{for(let j=-9;j<=9;j++)for(let i=-7;i<=7;i++){const d=Math.hypot(i,j),k=(D.ty+j)*N+D.tx+i;if(d<=6)M[k]=t;else if(d<=7.5)M[k]=Math.abs(i)<=1&&j>0?t:4;else if(j>7&&Math.abs(i)<=1)M[k]=2}};
let DU,DL;const place=(s,ok)=>{for(let k=0;k<2000;k++){const x=16+(hs(k,s,5)*(N-32)|0),y=16+(hs(k,s+1,5)*(N-32)|0),t=M[y*N+x],d=Math.hypot(x-N/2,y-N/2);if((t==2||t==3)&&M[(y+10)*N+x]>0&&ok(d)&&V.every(v=>Math.hypot(v.tx-x,v.ty-y)>24)&&[DG,DU,DL].every(q=>!q||Math.hypot(q.tx-x,q.ty-y)>22))return{tx:x,ty:y}}};
DU=place(11,d=>d<N*.36);if(DU)carve(DU,10);
DL=place(21,d=>d>N*.12);if(DL)carve(DL,11);
const RC=new Uint8Array(N*N),wk=t=>t==1||t==2||t==3||t==6||t==7||t>=9&&t<=20;
{const q=[V[0].ty*N+V[0].tx];RC[q[0]]=1;for(let h=0;h<q.length;h++){const c=q[h],cx=c%N,cy=c/N|0;[[1,0],[-1,0],[0,1],[0,-1]].forEach(([a,b])=>{const x=cx+a,y=cy+b;if(x<0||y<0||x>=N||y>=N)return;const k=y*N+x;if(!RC[k]&&wk(M[k])){RC[k]=1;q.push(k)}})}}
const RR=8,RP=[];
for(let n=0;n<8;n++){let f=null;for(let k=0;k<12000&&!f;k++){const x=RR+6+(hs(k,30+n,5)*(N-2*RR-12)|0),y=RR+6+(hs(k,60+n,5)*(N-2*RR-14)|0);if(!RC[(y+RR+5)*N+x]||M[y*N+x]==0)continue;if(V.every(v=>Math.hypot(v.tx-x,v.ty-y)>24)&&[DG,DU,DL,...RP].every(q=>!q||Math.hypot(q.tx-x,q.ty-y)>30)&&(n>3||Math.hypot(V[0].tx-x,V[0].ty-y)<62))f={tx:x,ty:y}}if(f)RP.push(f)}
RP.sort((a,b)=>Math.hypot(a.tx-V[0].tx,a.ty-V[0].ty)-Math.hypot(b.tx-V[0].tx,b.ty-V[0].ty));
RP.forEach((D,t)=>{for(let j=-RR-4;j<=RR+4;j++)for(let i=-RR-4;i<=RR+4;i++){const x=D.tx+i,y=D.ty+j;if(x<1||y<1||x>=N-1||y>=N-1)continue;const d=Math.hypot(i,j),k=y*N+x;if(d<=RR)M[k]=12+t;else if(d<=RR+1.5)M[k]=Math.abs(i)<=1&&j>0?12+t:4;else if(j>RR&&Math.abs(i)<=1)M[k]=2}});
const CS=RP[7]||{tx:V[V.length-1].tx,ty:V[V.length-1].ty};
// ---- 신규 히든 맵: 보이드 차원 (타일 20) ----
let VD=null;for(const[da,db]of[[26,28],[20,22],[16,18]])for(let k=0;k<3000&&!VD;k++){const x=22+(hs(k,41,5)*(N-44)|0),y=22+(hs(k,42,5)*(N-44)|0),t=M[y*N+x];if((t==2||t==3)&&RC[y*N+x]&&RC[(y+10)*N+x]&&V.every(v=>Math.hypot(v.tx-x,v.ty-y)>da)&&[DG,DU,DL,...RP].every(q=>!q||Math.hypot(q.tx-x,q.ty-y)>db))VD={tx:x,ty:y}}
if(VD)carve(VD,20);
const RDm=[];RP.forEach((q,i)=>{const d=Math.hypot(q.tx-V[0].tx,q.ty-V[0].ty);RDm.push(i?Math.max(d,RDm[i-1]+6):d)});const RLm=RG.map(g=>(g.lv[0]+g.lv[1])/2);
const fieldLv=(x,y)=>{const d=Math.hypot(x/TS-V[0].tx,y/TS-V[0].ty);if(!RDm.length)return Math.max(1,Math.min(100,1+(d/6|0)));if(d<=RDm[0])return Math.max(1,Math.round(1+(RLm[0]-1)*d/Math.max(1,RDm[0])));for(let i=1;i<RDm.length;i++)if(d<=RDm[i])return Math.round(RLm[i-1]+(RLm[i]-RLm[i-1])*(d-RDm[i-1])/Math.max(1,RDm[i]-RDm[i-1]));return Math.min(100,Math.round(RLm[RDm.length-1]+(d-RDm[RDm.length-1])/4))};
const ZL={6:[0,3],7:[0,5],9:[30,8],10:[22,6],11:[45,10],20:[80,10]};
const zoneLv=(x,y)=>{const t=M[(y/TS|0)*N+(x/TS|0)],z=ZL[t],f=fieldLv(x,y);return z?Math.min(100,Math.max(z[0],f+z[1])):f};
const regLv=(gi,x,y)=>{const g=RG[gi],q=RP[gi];if(!q)return g.lv[0];const d=Math.min(1,Math.hypot(x-(q.tx+.5)*TS,y-(q.ty+.5)*TS)/(RR*TS));return Math.round(g.lv[0]+(g.lv[1]-g.lv[0])*(1-d))};
const LGD=[{id:'red',n:'레드 드래곤',s:'drgR',hp:40000,d:60,sp:1.1,r:26,gem:3000,nu:1,tt:[7]},{id:'green',n:'그린 드래곤',s:'drgG',hp:40000,d:60,sp:1.1,r:26,gem:3000,nu:1,tt:[3]},{id:'blue',n:'블루 드래곤',s:'drgB',hp:45000,d:65,sp:1.2,r:26,gem:3500,nu:1,tt:[2]},{id:'ice',n:'아이스 드래곤',s:'drgI',hp:45000,d:65,sp:1.2,r:26,gem:3500,nu:1,tt:[6]},{id:'sea',n:'바다용',s:'sdrg',hp:50000,d:70,sp:1.3,r:26,gem:4000,nu:1,sea:1,tt:[0]},{id:'imugi',n:'이무기',s:'imugi',hp:60000,d:80,sp:1.4,r:24,gem:6000,nu:0},{id:'bone',n:'본드래곤',s:'bdrg',hp:90000,d:100,sp:1.3,r:30,gem:10000,nu:0},{id:'void',n:'보이드 드래곤',s:'vdrg',hp:90000,d:100,sp:1.3,r:30,gem:12000,nu:0,tt:[2,3]}];
LGD.forEach(g=>{const o={red:[55,3,1.2],green:[48,3,1.2],blue:[52,3,1.2],ice:[52,3,1.2],sea:[58,3.2,1.3],imugi:[70,3,1.3],bone:[88,3.6,1.5],void:[300,3.4,1.4]}[g.id];g.lv=o[0];g.hp=mHP(o[0],o[1]);g.d=mDM(o[0],o[2])});
const LGP=[];const lgFind=(tt,i,sea)=>{for(let k=0;k<4000;k++){const x=10+(hs(k,70+i,5)*(N-20)|0),y=10+(hs(k,90+i,5)*(N-20)|0),t0=M[y*N+x];if(!tt.includes(t0))continue;const R=sea?3:tt.includes(3)&&tt.length==1?0:2;let ok=1;for(let j=-R;j<=R&&ok;j++)for(let a=-R;a<=R;a++)if(M[(y+j)*N+x+a]!==t0){ok=0;break}if(!ok||!V.every(v=>Math.hypot(v.tx-x,v.ty-y)>(sea?10:20))||!LGP.every(q=>Math.hypot(q.tx-x,q.ty-y)>22))continue;if(sea){let nb=0;for(let j=-9;j<=9&&!nb;j++)for(let a=-9;a<=9;a++)if(M[(y+j)*N+x+a]==1){nb=1;break}if(!nb)continue}return{tx:x,ty:y}}};
const LGS=LGD.map((g,i)=>{const p=i==7&&VD?VD:i==5?(RP[4]||lgFind([3],i)):i==6?(DU||DG||lgFind([3],i)):(lgFind(g.tt,i,g.sea)||lgFind([2,3,1],i));if(p&&(i<5||i==7))LGP.push(p);return{...g,x:p?(p.tx+.5)*TS:V[0].x+TS*12,y:p?(p.ty+.5)*TS:V[0].y+TS*12,at:0}});
const NP=[{k:'job',x:V[0].x+TS*3,y:V[0].y+TS*2,s:'sage'}];if(DG)NP.push({k:'hid',h:'time',x:(DG.tx+.5)*TS,y:(DG.ty+1.5)*TS,s:'seer',hl:'🌌 시공의 전당',hc:'#2a1f4a',rc:'#6a3ac8',hg:'#b05bff',hw:72,hh:1});
const NEST=DL?{x:(DL.tx+.5)*TS,y:(DL.ty+.5)*TS+46}:null;
const TL=[{n:'검사',ic:'⚔️',j:[1,5],f:1,c:'r'},{n:'궁수',ic:'🏹',j:[2,6],f:2,c:'g'},{n:'마법사',ic:'🔮',j:[3,7],f:3,c:'b'},{n:'도적',ic:'🗡️',j:[4,8],f:4,c:'a'},{n:'테이머',ic:'🐾',j:[10],f:10,c:'T'}];
const HV=V.slice(1,V.length-1).sort((a,b)=>Math.hypot(a.tx-V[0].tx,a.ty-V[0].ty)-Math.hypot(b.tx-V[0].tx,b.ty-V[0].ty));
SP.palnpc=mk(SP.npc.R.map(r=>r.replace(/p/g,'L')),3);
TL.forEach((t,i)=>{SP['tr'+i]=mk(SP.npc.R.map(r=>r.replace(/p/g,t.c)),3);NP.push({k:'tr',c:i,x:(HV[i].tx+3.5)*TS,y:(HV[i].ty+4.5)*TS,s:'tr'+i,hl:t.ic+t.n+' 전직관',hc:'#7a6a50',rc:PAL[t.c],hg:'#ffe680',hw:64})});
const TRI={"tr0": IM["images/TRI_tr0.webp"], "tr1": IM["images/TRI_tr1.webp"], "tr2": IM["images/TRI_tr2.webp"], "tr3": IM["images/TRI_tr3.webp"], "tr4": IM["images/TRI_tr4.webp"], "seer": IM["images/TRI_seer.webp"], "palnpc": IM["images/TRI_palnpc.webp"]};Object.keys(TRI).forEach(k=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=im.width;c.height=im.height;c.getContext('2d').drawImage(im,0,0);SP[k]=c};im.src=TRI[k]});
if(DU)NP.push({k:'hid',h:'pal',x:(DU.tx+.5)*TS,y:(DU.ty+1.5)*TS,s:'palnpc',hl:'⛪ 성기사의 성역',hc:'#d8d2c0',rc:'#ffd84a',hg:'#fff3a0',hw:72,hh:1});
if(DL)NP.push({k:'gd',x:(DL.tx+.5)*TS,y:(DL.ty+.5)*TS-10,s:'gold'});
for(let k=0;CH.length<110&&k<3000;k++){const x=4+(hs(k,4,9)*(N-8)|0),y=4+(hs(k,5,9)*(N-8)|0),t=M[y*N+x];if(t==1||t==2||t==6||t==7||t==9)CH.push({x:(x+.5)*TS,y:(y+.5)*TS,o:0})}
[DU,DL].forEach(q=>q&&[[-3,-3],[3,-3],[-3,3],[3,3]].forEach(([a,b])=>CH.push({x:(q.tx+a+.5)*TS,y:(q.ty+b+.5)*TS,o:0,b:3})));
if(VD)[[-3,-3],[3,-3],[-3,3],[3,3],[0,-4],[0,4],[-4,0],[4,0]].forEach(([a,b])=>CH.push({x:(VD.tx+a+.5)*TS,y:(VD.ty+b+.5)*TS,o:0,b:10}));
RP.forEach((q,k)=>[[-3,-2],[3,-2],[0,3]].forEach(([a,b])=>CH.push({x:(q.tx+a+.5)*TS,y:(q.ty+b+.5)*TS,o:0,b:3+k*4})));
const MM=document.createElement('canvas');MM.width=MM.height=N;{const g=MM.getContext('2d');for(let y=0;y<N;y++)for(let x=0;x<N;x++){g.fillStyle=CL[M[y*N+x]==11?4:M[y*N+x]];g.fillRect(x,y,1,1)}}
const blocked=(x,y)=>{const t=M[(y/TS|0)*N+(x/TS|0)];return !(t==1||t==2||t==3||t==6||t==7||t>=9&&t<=20)};
const okP=(x,y)=>{if(x<0||y<0||x>=N*TS||y>=N*TS)return false;return M[(y/TS|0)*N+(x/TS|0)]==0||!blocked(x,y)};
const walkP=(o,dx,dy,r)=>{if(okP(o.x+dx,o.y+r))o.x+=dx;if(okP(o.x,o.y+dy+r))o.y+=dy};
const walk=(o,dx,dy,r)=>{if(!blocked(o.x+dx,o.y+r))o.x+=dx;if(!blocked(o.x,o.y+dy+r))o.y+=dy};
const walkS=(o,dx,dy,r)=>{const ok=(x,y)=>M[(y/TS|0)*N+(x/TS|0)]==0;if(ok(o.x+dx,o.y+r))o.x+=dx;if(ok(o.x,o.y+dy+r))o.y+=dy};
