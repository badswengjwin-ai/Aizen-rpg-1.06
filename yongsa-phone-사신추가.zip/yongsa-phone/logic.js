// ---- state ----
let P,E,Q,T,CX=0,CY=0,st='title',keys={},jx=0,jy=0,jo=null,TO={t:'',l:0};
const toast=t=>TO={t,l:110};
function ov(h,p,btns){O.style.display='flex';O.innerHTML=`<h2>${h}</h2><p>${p}</p>`;btns.forEach(([t,f])=>{const b=document.createElement('button'),mm=/^§(\d+)§/.exec(t),mq=/^¤(\d+)¤/.exec(t);if(mq){t=t.slice(mq[0].length);const im=document.createElement('img'),sp=document.createElement('span');im.src=SKI[+mq[1]];im.style.cssText='width:40px;height:40px;flex:none;border-radius:6px';sp.textContent=t;b.style.cssText='display:flex;align-items:center;justify-content:center;gap:8px;white-space:pre-line';b.append(im,sp)}else if(mm){t=t.slice(mm[0].length);const im=document.createElement('img'),sp=document.createElement('span');im.src=WICD[+mm[1]];im.style.cssText='width:40px;height:40px;flex:none';sp.textContent=t;b.style.cssText='display:flex;align-items:center;justify-content:center;gap:8px;white-space:pre-line';b.append(im,sp)}else{const ji=/전직/.test(t)?JB.findIndex((j,q)=>q>0&&t.split('\n')[0].includes(j[0])):-1;if(ji>0&&JPI[ji].naturalWidth){const im=document.createElement('img'),sp=document.createElement('span');im.src=JPD[ji];im.style.cssText='height:46px;flex:none';sp.textContent=t;b.style.cssText='display:flex;align-items:center;justify-content:center;gap:8px;white-space:pre-line';b.append(im,sp)}else b.textContent=t}b.onclick=()=>{O.style.display='none';f()};O.appendChild(b)})}
function reset(){const v=V[0];P={x:v.x,y:v.y+TS*2,hp:100,max:100,sp:2.5,atk:10,cd:0,rate:40,rg:46,xp:0,nx:20,lv:1,inv:0,dash:0,dd:0,f:1,g:0,pot:2,j:0,w:0,sk:0,ow:[1],os:[1],hid:0,bk:0,ws:0,ows:[1],ar:0,oar:[1],dk:0,bf:0,bm:1,pets:[],z:0,sc:[0,0,0,0],auto:1,it:{bone:0,heart:0},ks:['rel'],eq:[null,null,null],kc:0,xc:[0,0,0],uk:0,pk:0,wt:0};calc();P.hp=P.max;const b=V[V.length-1];E=[{...TY[3],x:(CS.tx+.5)*TS,y:(CS.ty+.5)*TS,max:TY[3].hp,kx:0,ky:0,boss:1,lv:85}];Q=null;T=0;CH.forEach(c=>c.o=0)}
const mkLg=g=>({t:40,s:g.s,x:g.x,y:g.y,hp:g.hp,max:g.hp,sp:g.sp,d:g.d,r:g.r,gem:g.gem,el:0,kx:0,ky:0,lg:g.id,lv:g.lv,nm:g.n,nu:g.nu,sea:g.sea,nt:(g.id=='bone'||g.id=='void'||g.id=='imugi'&&!(P.it.bone>0&&P.it.heart>0))?1:0});
function init(){reset();st='play'}
function spawn(){const pz=M[(P.y/TS|0)*N+(P.x/TS|0)],a=Math.random()*6.283,r=pz>=9?50+Math.random()*90:220+Math.random()*80,x=P.x+Math.cos(a)*r,y=P.y+Math.sin(a)*r;if(blocked(x,y))return;const tt=M[(y/TS|0)*N+(x/TS|0)];if((pz>=9||tt>=9)&&pz!=tt)return;if(E.filter(e=>!e.boss&&!e.lg&&(tt>=9?M[(e.y/TS|0)*N+(e.x/TS|0)]==tt:Math.hypot(e.x-P.x,e.y-P.y)<420)).length>=5)return;
const el=Math.random()<.1,hm=el?3:1,ef=el?1.5:1;
if(tt==20){const vm=[{s:'vwraith',h:1,dm:1,r:15,sp:1.5},{s:'veye',h:1.6,dm:1.25,r:14,sp:1.2},{s:'demonP',h:2,dm:1.4,r:16,sp:1.5},{s:'vskel',h:1.5,dm:1.3,r:20,sp:1.3,L:100,gm:1,nm:'해골기사'},{s:'jorm',h:2,dm:1.5,r:28,sp:1.1,L:200,gm:2,nm:'요르문간드'},{s:'vlich',h:3,dm:1.6,r:24,sp:1.2,L:150,gm:4,nm:'리치킹'}],rq=Math.random(),m=(rq<.05&&!E.some(q=>q.s=='vlich'||q.lg=='void'))?vm[5]:(rq<.1&&!E.some(q=>q.s=='jorm'))?vm[4]:rq<.3?vm[3]:vm[Math.random()<.2?2:Math.random()<.45?1:0],L=m.L||zoneLv(x,y),hp=Math.round(mHP(L,m.h)*hm);E.push({t:41,s:m.s,lv:L,x,y,hp,max:hp,sp:m.sp*(el?1.1:1),d:Math.round(mDM(L,m.dm)*ef),r:m.r*(el?1.3:1),gem:m.L?Math.round(mGM(Math.min(L,100))*m.gm*(el?4:1)):Math.round(mGM(L)*(el?4:1)*1.3),nm:m.nm,el,kx:0,ky:0});return}if(tt>=12){const gi=tt-12,g=RG[gi],m=g.m[Math.random()<.35?1:0],L=regLv(gi,x,y),hp=Math.round(mHP(L,m.h)*hm);E.push({t:20+tt,s:m.s,lv:L,x,y,hp,max:hp,sp:m.sp*(el?1.1:1),d:Math.round(mDM(L,m.dm)*ef),r:m.r*(el?1.3:1),gem:Math.round(mGM(L)*(el?4:1)),el,kx:0,ky:0});return}
const L=zoneLv(x,y),p0=tt==6?[4,2]:tt==7?[6,2,4]:tt==9?[7]:tt==10?[2,6,7]:tt==11?[8]:tt==1&&L>=8?[5,0]:L<3?[0]:L<8?[0,1]:L<20?[0,1,2]:L<35?[1,2,4]:L<50?[2,4,6]:[4,6,2],pl=(Q&&Q.t<3&&tt<9&&Math.random()<.4)?[Q.t]:p0,b=TY[pl[Math.random()*pl.length|0]],hp=Math.round(mHP(L,b.hk)*hm);
E.push({...b,lv:L,x,y,hp,max:hp,d:Math.round(mDM(L,b.dk)*ef),gem:Math.ceil(mGM(L)*b.gk*.7)*(el?4:1),r:b.r*(el?1.3:1),sp:b.sp*(el?1.1:1),el,kx:0,ky:0})}

function dash(){if(st==='play'&&P.dd<=0){P.dash=8;P.dd=70;P.inv=Math.max(P.inv,14)}}
function usePot(){if(st==='play'&&P.pot>0&&P.hp<P.max){P.pot--;P.hp=Math.min(P.max,P.hp+Math.max(60,P.max*.4|0))}}
const near=()=>V.findIndex(v=>Math.hypot(v.x-P.x,v.y+TS-P.y)<56);const nearN=()=>NP.findIndex(n=>Math.hypot(n.x-P.x,n.y-P.y)<50);const act=()=>{if(st!=='play')return;const n=nearN();n>=0?npc(n):talk(near())};
function talk(i){if(i<0||st==='ui'&&!i&&0)return;const v=V[i],b=[];st='ui';let p;
if(Q&&Q.v==i&&Q.c>=Q.n){P.g+=Q.g;P.xp+=Q.x;p=`고마워요, 용사님! 보상 ${Q.g}G를 드릴게요.`;Q=null}
else if(Q)p=`${Q.name} ${Q.c}/${Q.n} 처치... 부탁해요!`;
else{p=v.q.say;b.push(['⚔️ 퀘스트 수락',()=>{Q={...v.q,v:i,c:0};st='play'}])}
b.push(['🧪 물약 구매 (25G)',()=>{if(P.g>=25){P.g-=25;P.pot++}talk(i)}],['🏪 상점',()=>shop(i)],['🛏️ 쉬기 (체력 회복)',()=>{P.hp=P.max;talk(i)}],['닫기',()=>st='play']);
ov(`마을 ${i+1}`,p+`<br>보유 ${P.g}G · 물약 ${P.pot}`,b)}
function shop(i,t){st='ui';const b=[];
if(!t){b.push(['⚔️ 무기',()=>shop(i,1)],['🎨 스킨',()=>shop(i,2)],['🗡️ 무기 스킨',()=>shop(i,3)],['🛡️ 갑옷',()=>shop(i,4)],['🧪 물약 3개 (70G)',()=>{if(P.g>=70){P.g-=70;P.pot+=3}shop(i)}],['← 뒤로',()=>talk(i)])}
else{const w=t==1,L=w?WP:t==3?WSK:t==4?AR:SKN,O=w?P.ow:t==3?P.ows:t==4?P.oar:P.os,K=w?'w':t==3?'ws':t==4?'ar':'sk',pr=w?4:t==4?3:2;(w?[...L.keys()].sort((p,q)=>L[p][1]-L[q][1]):[...L.keys()]).forEach(k=>{const x=L[k];b.push([`${w&&WICD[k]?`§${k}§`:''}${x[0]}${t==4?` 🛡️-${x[1]*100|0}% ❤️+${x[2]}`:''}${w?` [${GR[x[9]][0]}] ⚔️${x[10]=='x'?'???':x[1]} 📏${x[2]}`:''}\n${P[K]==k?'✅ 장착중':O[k]?'장착하기':w&&x[10]=='d'?'🔒 드랍 전용':w&&x[10]=='x'?'🔒 획득 불가':x[pr]+'G'}`,()=>{if(!(w&&!O[k]&&x[10]!='s')&&(O[k]||P.g>=x[pr])){if(!O[k]){P.g-=x[pr];O[k]=1}P[K]=k;calc()}shop(i,t)}])});b.push(['← 뒤로',()=>shop(i)])}
ov('🏪 상점',`보유 ${P.g}G · 물약 ${P.pot}`+(t==1?`<br><small>${GRT}</small>`:''),b)}
function hidHall(n){st='ui';const b=[],j=P.j;let p,h;
if(n.h=='time'){h='🌌 시공의 전당';
if(P.hid){p='시공의 힘이 당신을 알아봅니다.';if(j!=9)b.push([`🌌 시공의 용사로 전직\n${JB[9][6]}`,()=>chg(9)]);else p+='<br>이미 시공의 용사예요!'}
else if(P.lv<30||!P.bk)p='…아직 부족하다.<br><small>조건: Lv.30 + 마왕 처치 (현재 Lv.'+P.lv+(P.bk?'':' · 마왕 미처치')+')</small>';
else{P.hid=1;p='제단이 응답했다! 시공의 힘이 열렸습니다.';b.push([`🌌 시공의 용사로 전직\n${JB[9][6]}`,()=>chg(9)])}}
else{h='⛪ 성기사의 성역';p='어둠 속에서 빛을 지키는 자들의 성역입니다.<br>시련: 지하 던전 몬스터 30마리 처치 ('+Math.min(P.uk||0,30)+'/30)';
if(P.pk||(P.lv>=35&&(P.uk||0)>=30)){P.pk=1;if(j!=12)b.push([`⛪ 성기사로 전직\n${JB[12][6]}`,()=>chg(12)]);else p+='<br>이미 성기사예요!'}else p+='<br><small>조건: Lv.35 + 시련 완료</small>'}
b.push(['닫기',()=>st='play']);ov(h,p,b)}
function hall(n){const px=n.x-CX,py=n.y-CY,w=n.hw||64;if(px<-90||px>W+90||py<-10||py>H+130)return;
X.save();if(n.hh){X.shadowColor=n.hg;X.shadowBlur=14+Math.sin(T/14)*5;X.strokeStyle=n.hg;X.globalAlpha=.45+Math.sin(T/14)*.15;X.lineWidth=2;X.beginPath();X.ellipse(px,py-2,w*.7,10,0,0,7);X.stroke();X.globalAlpha=1}
X.fillStyle='rgba(0,0,0,.28)';X.beginPath();X.ellipse(px,py-4,w/2+8,7,0,0,7);X.fill();
X.fillStyle=n.hc;X.fillRect(px-w/2,py-56,w,50);X.fillStyle='rgba(0,0,0,.2)';X.fillRect(px-w/2,py-56,w,5);X.fillRect(px+w/2-6,py-56,6,50);
X.fillStyle=n.rc;X.beginPath();X.moveTo(px-w/2-8,py-54);X.lineTo(px,py-84);X.lineTo(px+w/2+8,py-54);X.closePath();X.fill();
X.fillStyle='rgba(255,255,255,.2)';X.beginPath();X.moveTo(px-w/2-8,py-54);X.lineTo(px,py-84);X.lineTo(px,py-54);X.closePath();X.fill();
X.fillStyle='#2a1a10';X.fillRect(px-7,py-30,14,24);X.fillStyle='#ffd84a';X.fillRect(px+3,py-18,2,3);
X.fillStyle=n.hg;X.fillRect(px-w/2+7,py-44,10,10);X.fillRect(px+w/2-17,py-44,10,10);
X.shadowBlur=0;X.fillStyle='rgba(10,12,30,.88)';X.fillRect(px-52,py-103,104,16);X.strokeStyle=n.hh?n.hg:'#ffd84a';X.lineWidth=1;X.strokeRect(px-52,py-103,104,16);
X.font='11px sans-serif';X.fillStyle=n.hh?n.hg:'#ffd84a';X.textAlign='center';X.fillText(n.hl,px,py-91);X.textAlign='left';X.restore()}
function chg(k){P.j=k;calc();P.hp=P.max;toast('전직! '+JB[k][0]);st='ui';ov('✨ 전직 완료!',`<img src="${JPD[k]}" style="height:104px;display:block;margin:6px auto"><b>${JB[k][0]}</b><br><small>${SKJ[k].map(q=>q[0]+q[1]).join(' · ')}</small>`,[['계속',()=>st='play']])}
const GDIMG=IM['images/GDIMG_001.webp'];
function GPi(x){return GDIMG}
let VT=null;
function vnx(ex,name,text,sc,btns,pop){clearInterval(VT);st='ui';const k=Math.min(8,Math.max(0,sc)),hr='💛'.repeat(k)+'🤍'.repeat(8-k);O.style.display='flex';
O.innerHTML=`<div style="width:100%;color:#ffd84a;font-size:15px">${hr}${pop?` <b style="color:${pop[0]=='+'?'#7bd88f':'#ff6a6a'}">${pop}</b>`:''}</div><img src="${GPi(ex)}" style="width:190px;max-height:46vh;object-fit:contain;filter:drop-shadow(0 0 14px #ffd84a)${ex=='a'?' saturate(1.6) hue-rotate(-12deg)':ex=='s'?' brightness(.85) saturate(.7)':ex=='b'?' sepia(.25) saturate(1.5) hue-rotate(-20deg)':''}"><div id="vb" style="width:100%;background:rgba(10,12,30,.92);border:2px solid #ffd84a;border-radius:10px;padding:10px;text-align:left"><div style="color:#ffd84a;margin-bottom:4px">${name}</div><div id="vt" style="font-size:15px;line-height:1.5;min-height:70px"></div></div><div id="vc" style="width:100%;display:flex;flex-direction:column;gap:6px;align-items:center"></div>`;
const tx=document.getElementById('vt'),vc=document.getElementById('vc');let i=0;const done=()=>{clearInterval(VT);tx.textContent=text;if(!vc.children.length)btns.forEach(([t,f])=>{const b=document.createElement('button');b.textContent=t;b.onclick=f;vc.appendChild(b)})};
VT=setInterval(()=>{tx.textContent=text.slice(0,++i);if(i>=text.length)done()},28);document.getElementById('vb').onclick=done}
const GQ=[
{x:'n',t:'…인간이 내 둥지에 발을 들였군. 이 대륙의 용들은 인간을 믿지 않는다. 너는 무엇을 위해 왔지?',c:[['"용들과 친구가 되고 싶어서 왔어요."',1,'h','…친구? 용에게 그런 말을 하는 인간은 처음이군. (피식)'],['"당신의 힘이 필요해서 왔다!"',-1,'a','힘을 빌리러 왔다고? 용은 도구가 아니다!'],['"…그냥 구경 왔는데요."',0,'n','…제멋대로인 녀석이군.']]},
{x:'s',t:'오래전, 인간 용사가 내 새끼들의 알을 훔쳐 갔다. 그 뒤로 용들은 인간을 적으로 본다. …이 이야기를 듣고 무슨 생각이 드느냐?',c:[['"정말 미안해요. 그 아픔을 이해해요."',2,'b','…! (눈을 크게 뜨고 시선을 피한다) 인간이 사과를 하다니…'],['"옛날 일이잖아요. 이제 잊을 때도 됐죠."',-2,'a','잊어? 내 새끼들을 잃은 걸 잊으라고?!'],['"알을 되찾도록 제가 도울게요."',1,'h','…훗, 말만이라도 고맙군.']]},
{x:'n',t:'…입에 발린 말은 질렸다. 용은 진심을 꿰뚫어 본다. 네가 지키고 싶은 것은 무엇이냐?',c:[['"이 대륙의 모든 생명이요. 용도 포함해서요."',2,'b','…용도 포함, 이라고? (뺨이 살짝 붉어진다)'],['"제 명예와 부요."',-1,'s','…그런가. 역시 인간은…'],['"소중한 사람들이요."',1,'h','소중한 이를 지키려는 마음… 나쁘지 않군.']]},
{x:'a',t:'(황금빛 눈이 가늘어진다) 마지막으로 묻겠다. 내가 지금 널 불태우려 한다면, 넌 어떻게 하겠느냐?',c:[['무기를 내려놓고 눈을 똑바로 마주 본다.',3,'b','…!! 바, 바보 같은 녀석… 왜 피하지 않는 거냐…'],['"덤벼요! 내가 이겨요!"',-2,'a','오만한 것! 불태워 주마!'],['"그럼 먼저 도망갈게요!"',-1,'n','…하. 한심하군.'],['"당신은 그럴 용이 아니라는 걸 알아요."',2,'h','…어떻게 그걸… 알고 있었던 거냐.']]}];
const bye=()=>{O.style.display='none';st='play'},jn=()=>{O.style.display='none';P.dk=1;chg(11)};
function gd(q,sc,pop){if(q<0)return vnx('n','???','…………(둥지 깊은 곳에서 황금빛 머리카락을 늘어뜨린 인물이 천천히 고개를 든다. 이마에는 뿔이, 눈에는 용의 위엄이 깃들어 있다.)',0,[['▶ 다가간다',()=>gd(0,0)],['물러난다',bye]]);
if(q>=4)return gde(sc);const n=GQ[q];
vnx(n.x,'골드 드래곤',n.t,sc,n.c.map(([t,d,x,r])=>[t,()=>vnx(x,'골드 드래곤',r,sc+d,[['▶ 다음',()=>gd(q+1,sc+d)]],d>0?'+'+d+'💛':d<0?d+'💔':'')]))}
function gde(sc){if(sc>=6){const b=[['🐉 용기사로 전직',jn]];vnx('b','골드 드래곤','…크르르. 네 눈에는 거짓이 없구나. 좋다, 인간. 황금룡의 이름으로 너와 계약하겠다. 오늘부터 너는 용기사다!',sc,sc>=8?[['▶ 다음',()=>vnx('b','골드 드래곤','…그, 그리고… 앞으로도 내 곁에 있어도 좋다. (…가슴이 왜 이렇게 뛰는 거지)',sc,b)]]:b)}
else if(sc>=3)vnx('n','골드 드래곤','…아직은 믿을 수 없다. 더 진심을 보이고 오거라, 인간.',sc,[['다시 도전',()=>gd(0,0)],['물러난다',bye]]);
else{P.hp=Math.max(1,P.hp*.5|0);vnx('a','골드 드래곤','건방진 것! 꺼져라! (황금 불꽃에 체력이 반으로 줄었다…)',sc,[['도망친다',bye]])}}
function gdt(){if(!P.dk&&P.lv<45)return vnx('n','골드 드래곤','…약한 자와는 말을 섞지 않는다. 더 강해져서 오거라, 인간. (Lv.45 필요)',0,[['물러난다',bye]]);if(P.dk){const b=[];if(P.j!=11)b.push(['🐉 용기사로 전직',jn]);b.push(['닫기',bye]);vnx('h','골드 드래곤','용기사여, 언제든 돌아오거라.',8,b)}else gd(-1,0)}
function dirTo(o){const dx=o.x-P.x,dy=o.y-P.y,ar=['→','↘','↓','↙','←','↖','↑','↗'][Math.round(Math.atan2(dy,dx)/(Math.PI/4)+8)%8];return `${ar} ${Math.round(Math.hypot(dx,dy)/TS)}칸`}
function guide(){st='ui';const L=[];NP.forEach(n=>{if(n.k=='tr')L.push(`${TL[n.c].ic} ${TL[n.c].n} 전직관 ${dirTo(n)}`)});NP.forEach(n=>{if(n.k=='hid')L.push(`★ ${n.hl.slice(2)} ${dirTo(n)}`);if(n.k=='gd')L.push(`★ 용기사 전직관(용의 굴) ${dirTo(n)}`)});
ov('⛩️ 전직 안내소',`전직은 각 전직관에서 해요.<br>Lv.10 1차 · Lv.25 2차 전직<br><small>${L.join('<br>')}</small><br><small>(미니맵 주황 점=일반 전직관, 보라 점=히든)</small>`,[['닫기',()=>st='play']])}
function npc(i){const n=NP[i],b=[],j=P.j;if(n.k=='job')return guide();if(n.k=='gd')return gdt();if(n.k=='tr')return trn(n.c);if(n.k=='hid')return hidHall(n);st='ui';let p,h;
if(n.k=='job'){h='⛩️ 전직관';
if(j==0){if(P.lv<10)p='Lv.10이 되면 1차 전직을 할 수 있어요.';else{p='1차 전직! 걸어갈 길을 고르세요.';[1,2,3,4,10].forEach(k=>b.push([`${JB[k][0]}\n${JB[k][6]}`,()=>chg(k)]))}}
else if(j<5){if(P.lv<25)p=`${JB[j][0]}님, Lv.25에 2차 전직이 가능해요.`;else{p='2차 전직이 가능해요!';b.push([`${JB[UP[j]][0]}(으)로 전직\n${JB[UP[j]][6]}`,()=>chg(UP[j])])}}
else p=`${JB[j][0]}... 더 가르칠 게 없군요!`;
if(P.hid&&j!=9)b.push([`🌌 히든 전직: ${JB[9][0]}\n${JB[9][6]}`,()=>chg(9)]);
else if(!P.hid)p+='<br><small>소문: 숨겨진 심연에 제단이 있다고…</small>'}
else{h='🔮 심연의 제단';if(P.hid)p='제단이 고요히 빛난다. 전직관을 찾아가라.';else if(P.lv<30||!P.bk)p='…아직 부족하다. (Lv.30 + 마왕 처치)';else{P.hid=1;p='제단이 응답했다! 히든 전직이 열렸다. 마을 전직관에게 가라.'}}
b.push(['닫기',()=>st='play']);ov(h,p,b)}
function gain(k){if(P.ow[k])return;P.ow[k]=1;toast(`🎁 ${GR[WP[k][9]][0]} 무기 획득: ${WP[k][0]}!`)}
const DROP_HARD=2;
function gainZ(){const l=[13,14,15,16,17,18,19].filter(k=>!P.ow[k]);if(l.length)gain(l[Math.random()*l.length|0])}
function drops(e){const r=Math.random()*DROP_HARD;if(e.boss){if(Math.random()<.08)gainZ()}else if(e.s==='dragon'&&Math.random()<(e.el?.04:.015))gainZ();if(e.boss){if(r<1)gain(10)}else if(e.s==='dragon'){if(e.el&&r<.06)gain(11);else if(r<(e.el?.2:.03))gain(10);else if(e.el&&r<.4)gain(9)}else if(e.el&&r<.07)gain(9)}
function kill(e){if(M[(e.y/TS|0)*N+(e.x/TS|0)]==10){P.uk=(P.uk||0)+1;if(P.uk==30)toast('⛪ 성기사의 시련 완료! 성역으로 가세요')}P.xp+=e.gem;P.g+=e.gem;toast(`+${e.gem}G`);if(e.lg){const g=LGS.find(q=>q.id==e.lg);if(g)g.at=Date.now()+3e5;if(e.lg=='bone'){P.it.bone++;toast('🦴 용의 뼈 획득!');if(Math.random()<.3&&!P.ks.includes('spc')){learn('spc');st='ui';ov('🌌 공허의 틈','본드래곤이 쓰러진 자리에 공간이 갈라졌다…<br>공허의 틈 속으로 빨려 들어가<br><b>공간참</b>을 깨우쳤다!<br><small>데미지 3000% · 쿨 30초</small>',[['계속',()=>st='play']])}}if(e.lg=='void')toast('🌌 보이드 드래곤 처치!');if(e.lg=='imugi'){P.it.heart++;toast('🐍 뱀의 심장 획득!')}}if(e.s=='vlich')P.lk={x:e.x,y:e.y};if(Q&&Q.t==e.t)Q.c++;drops(e);if(e.boss){P.bk=1;st='ui';ov('🏆 마왕 격파!','대륙에 평화가 찾아왔어요.'+(P.ow[10]?'<br>🎁 영웅 무기 획득: 천벌의 예기! (상점에서 장착)':''),[['계속 탐험',()=>st='play']])}}
