let FX=[],AH=0,JI=0,DB=null,ROOM=null,PEERS=[],ACC=null,ME='',PS={},BUB={},CHAT=[],MYB={t:'',l:0};
function bub(x,y,b){if(!b||b.l<=0)return;b.l--;X.font='12px sans-serif';const t=b.t.length>22?b.t.slice(0,21)+'…':b.t,w=X.measureText(t).width+12;X.globalAlpha=Math.min(1,b.l/40);X.fillStyle='rgba(13,16,32,.85)';X.fillRect(x-w/2,y-16,w,18);X.fillStyle='#fff';X.textAlign='center';X.fillText(t,x,y-3);X.textAlign='left';X.globalAlpha=1}
function openChat(){if(!ROOM||st!=='play')return;st='ui';O.style.display='flex';O.innerHTML='<h2>💬 채팅</h2><p>접속 중인 모든 용사에게 보여요.</p><input id="cm" maxlength="40" placeholder="메시지 (40자)" autocomplete="off"><button id="cs">보내기</button><button id="cx">닫기</button>';
const cm=document.getElementById('cm'),done=()=>{O.style.display='none';st='play'},send=()=>{const t=cm.value.trim();if(t)ROOM.emit('chat',{n:ME,t}).catch(()=>{});done()};
document.getElementById('cs').onclick=send;document.getElementById('cx').onclick=done;cm.addEventListener('keydown',e=>{if(e.key==='Enter')send()});setTimeout(()=>cm.focus(),50)}
let CURH='';
const NETURL=(()=>{const q=new URLSearchParams(location.search),sv=q.get('server'),rm=q.get('room');if(sv)return sv+(rm?(sv.includes('?')?'&':'?')+'room='+encodeURIComponent(rm):'');return /^https?:$/.test(location.protocol)?location.origin.replace(/^http/,'ws')+'/ws'+(rm?'?room='+encodeURIComponent(rm):''):''})();
function mkNet(url){return new Promise(resolve=>{if(!url||typeof WebSocket==='undefined')return resolve(null);
let ws=null,open=false,rid=0,back=1000;const pend=new Map(),pc=[],ev={};
const send=o=>{if(!open)return Promise.resolve();try{ws.send(JSON.stringify(o))}catch(e){}return Promise.resolve()};
const call=o=>new Promise((res,rej)=>{if(!open)return rej(new Error('offline'));const r=++rid,t=setTimeout(()=>{pend.delete(r);rej(new Error('timeout'))},8000);pend.set(r,{res,rej,t});try{ws.send(JSON.stringify({...o,r}))}catch(e){clearTimeout(t);pend.delete(r);rej(e)}});
const room={total:0,presence:d=>send({t:'p',d}),emit:(topic,d)=>send({t:topic==='chat'?'c':'x',d}),g:d=>send({t:'g',d}),on:(topic,fn)=>{(ev[topic]=ev[topic]||[]).push(fn);return()=>{}},onPeers:fn=>{pc.push(fn);return()=>{}}};
const db={doc:path=>{const k=path.split('/')[1];return{
get:async()=>{const m=await call({t:'get',k,h:CURH});if(m.err)throw new Error(m.err);if(!m.ex)return{exists:false,data:()=>null};return{exists:true,data:()=>({h:m.ok?CURH:'',p:m.p,t:m.ts})}},
set:async d=>{const m=await call({t:'set',k,h:d.h,p:d.p,ts:d.t});if(m.err)throw new Error(m.err);return m}}}};
const done=()=>{if(done.d)return;done.d=1;resolve({room,db})};
const conn=()=>{try{ws=new WebSocket(url)}catch(e){return done()}
ws.onopen=()=>{open=true;back=1000;done()};
ws.onmessage=e=>{let m;try{m=JSON.parse(e.data)}catch(x){return}
if(m.t==='s'){room.total=m.n|0;const peers=m.l.map(([id,d])=>({peer:id,isMe:false,sameTab:false,kind:'viewer',guest:false,presence:d}));pc.forEach(f=>{try{f({peers})}catch(x){}})}
else if(m.t==='c'){(ev.chat||[]).forEach(f=>{try{f({topic:'chat',data:m.d,peer:m.id,isMe:!!m.me,sameTab:!!m.me})}catch(x){}})}
else if(m.t==='g'){(ev.g||[]).forEach(f=>{try{f(m.d)}catch(x){}})}
else if(m.t==='r'){const p=pend.get(m.r);if(p){clearTimeout(p.t);pend.delete(m.r);p.res(m)}}};
ws.onclose=()=>{open=false;room.total=0;pc.forEach(f=>{try{f({peers:[]})}catch(x){}});pend.forEach(p=>{clearTimeout(p.t);p.rej(new Error('closed'))});pend.clear();done();setTimeout(conn,back);back=Math.min(back*2,10000)};
ws.onerror=()=>{try{ws.close()}catch(e){}}};
conn();setTimeout(done,4000)})}

const READY=(async()=>{try{if(typeof claude!=='undefined'){DB=await claude.use('db');ROOM=await claude.use('room')}else{const n=await mkNet(NETURL);if(n){DB=n.db;ROOM=n.room}}if(ROOM){ROOM.onPeers(c=>{PEERS=c.peers.filter(p=>!p.isMe&&p.presence&&p.presence.n);const kp={};PEERS.forEach(p=>{if(PS[p.peer])kp[p.peer]=PS[p.peer]});PS=kp});
ROOM.on('chat',m=>{const d=m.data;if(!d||typeof d.t!=='string')return;const t=d.t.slice(0,40),n=String(d.n||'?').slice(0,16);CHAT.push({n,t,l:600,me:!!m.isMe});if(CHAT.length>6)CHAT.shift();if(m.isMe)MYB={t,l:300};else BUB[m.peer]={t,l:300}})}}catch(e){}})();
