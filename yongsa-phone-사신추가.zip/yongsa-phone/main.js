const ab=document.getElementById('atk');ab.onpointerdown=()=>AH=1;ab.onpointerup=ab.onpointerleave=ab.onpointercancel=()=>AH=0;
reset();login();
loop();
